# reporting/telegram.py
import os
import json
from typing import Optional, Any, Dict, List, Tuple

import requests

from radar.config import RadarConfig


def _tg_token_chat(cfg: RadarConfig) -> Tuple[str, str]:
    token = (getattr(cfg, "telegram_token", "") or "").strip()
    chat_id = (getattr(cfg, "telegram_chat_id", "") or "").strip()

    token = (os.getenv("TELEGRAMTOKEN") or os.getenv("TG_BOT_TOKEN") or token).strip()
    chat_id = (os.getenv("CHATID") or os.getenv("TG_CHAT_ID") or chat_id).strip()
    return token, chat_id


def _chunk_text(text: str, limit: int = 3500):
    parts, buf = [], ""
    for line in text.splitlines(True):
        if len(buf) + len(line) > limit:
            parts.append(buf)
            buf = ""
        buf += line
    if buf.strip():
        parts.append(buf)
    return parts


def telegram_send_long(cfg: RadarConfig, text: str):
    token, chat_id = _tg_token_chat(cfg)

    if not token or not chat_id:
        print("⚠️ Telegram není nastaven: chybí token/chat_id.")
        return

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    for part in _chunk_text(text):
        try:
            r = requests.post(
                url,
                data={"chat_id": chat_id, "text": part, "disable_web_page_preview": True},
                timeout=35,
            )
            if r.status_code != 200:
                print("Telegram odpověď:", r.status_code, r.text[:400])
        except Exception as e:
            print("Telegram error:", e)


def telegram_send_photo(cfg: RadarConfig, path: str, caption: Optional[str] = None):
    token, chat_id = _tg_token_chat(cfg)
    if not token or not chat_id:
        return

    url = f"https://api.telegram.org/bot{token}/sendPhoto"
    try:
        with open(path, "rb") as f:
            files = {"photo": f}
            data = {"chat_id": chat_id, "caption": caption or ""}
            r = requests.post(url, data=data, files=files, timeout=60)
            if r.status_code != 200:
                print("Telegram photo odpověď:", r.status_code, r.text[:400])
    except Exception as e:
        print("Telegram photo error:", e)


def telegram_send_menu(cfg: RadarConfig) -> None:
    token, chat_id = _tg_token_chat(cfg)
    if not token or not chat_id:
        return

    kb = {
        "inline_keyboard": [
            [
                {"text": "📈 Snapshot", "callback_data": "snapshot"},
                {"text": "🚨 Alerty", "callback_data": "alerts"},
            ],
            [
                {"text": "🗓 Earnings", "callback_data": "earnings"},
                {"text": "🌍 Geo", "callback_data": "geo"},
            ],
            [
                {"text": "ℹ️ Help", "callback_data": "help"},
            ],
        ]
    }

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        requests.post(
            url,
            data={
                "chat_id": chat_id,
                "text": "Ovládací menu – klikni na akci:",
                "reply_markup": json.dumps(kb),
                "disable_web_page_preview": True,
            },
            timeout=35,
        )
    except Exception:
        pass


def telegram_poll_and_dispatch(cfg: RadarConfig, agent, st=None, max_updates: int = 25) -> Dict[str, Any]:
    """Polling dispatcher pro Telegram.

    - stáhne update-y přes getUpdates
    - callback tlačítka -> agent.handle(...)
    - text zprávy -> agent.handle(...)
    - offset ukládá do State (telegram.json) pokud je k dispozici
    """
    token, chat_id = _tg_token_chat(cfg)
    if not token or not chat_id:
        return {"ok": False, "reason": "no_token_or_chat"}

    offset = 0
    if st is not None and hasattr(st, "get_tg_offset"):
        offset = st.get_tg_offset()

    url = f"https://api.telegram.org/bot{token}/getUpdates"
    try:
        r = requests.post(url, data={"timeout": 0, "offset": offset, "limit": max_updates}, timeout=40)
        if r.status_code != 200:
            return {"ok": False, "reason": f"bad_status_{r.status_code}"}
        out = r.json()
        if not isinstance(out, dict) or not out.get("ok"):
            return {"ok": False, "reason": "not_ok"}
        updates = out.get("result") or []
    except Exception as e:
        return {"ok": False, "reason": f"exception_{e}"}

    handled = 0
    max_update_id = None

    for upd in updates:
        try:
            uid = upd.get("update_id")
            if isinstance(uid, int):
                max_update_id = uid if max_update_id is None else max(max_update_id, uid)

            # callback button
            if "callback_query" in upd:
                cq = upd.get("callback_query") or {}
                data = (cq.get("data") or "").strip()
                cq_id = cq.get("id")

                # ack callback
                if cq_id:
                    try:
                        requests.post(
                            f"https://api.telegram.org/bot{token}/answerCallbackQuery",
                            data={"callback_query_id": cq_id},
                            timeout=20,
                        )
                    except Exception:
                        pass

                if data == "help":
                    resp = agent.handle("help")
                else:
                    resp = agent.handle(data or "help")
                telegram_send_long(cfg, resp.markdown)
                handled += 1
                continue

            msg = upd.get("message") or upd.get("edited_message")
            if not isinstance(msg, dict):
                continue
            if str(msg.get("chat", {}).get("id", "")).strip() != str(chat_id).strip():
                continue

            text = (msg.get("text") or "").strip()
            if not text:
                continue

            cmd = text.split()[0].lower()
            if cmd in ("/start", "/menu"):
                telegram_send_menu(cfg)
                handled += 1
                continue

            resp = agent.handle(text)
            telegram_send_long(cfg, resp.markdown)
            handled += 1
        except Exception:
            continue

    # update offset
    if max_update_id is not None:
        new_offset = int(max_update_id) + 1
        if st is not None and hasattr(st, "set_tg_offset"):
            st.set_tg_offset(new_offset)
        if st is not None and hasattr(st, "save"):
            try:
                st.save()
            except Exception:
                pass

    return {"ok": True, "handled": handled, "offset": offset}
