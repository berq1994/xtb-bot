# reporting/emailer.py
import os
import smtplib
from datetime import datetime
from typing import Optional, List

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

from radar.config import RadarConfig


def _read_text(path: str, default: str = "") -> str:
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read().strip()
    except Exception:
        pass
    return default


def _env_bool(name: str, default: bool = False) -> bool:
    v = (os.getenv(name) or "").strip().lower()
    if v in ("1", "true", "yes", "y", "on"):
        return True
    if v in ("0", "false", "no", "n", "off"):
        return False
    return default


def maybe_send_email_report(
    cfg: RadarConfig,
    report: dict,
    now: datetime,
    tag: str = "report",
    attachments: Optional[List[str]] = None,
):
    """Odešle email report, pokud je EMAIL_ENABLED=true.

    Secrets/ENV:
    - EMAIL_SENDER
    - EMAIL_RECEIVER
    - GMAILPASSWORD (app password)
    - EMAIL_ENABLED=true
    """
    if not _env_bool("EMAIL_ENABLED", False):
        return

    sender = (os.getenv("EMAIL_SENDER") or "").strip()
    receiver = (os.getenv("EMAIL_RECEIVER") or "").strip()
    password = (os.getenv("GMAILPASSWORD") or "").strip()

    if not sender or not receiver or not password:
        print("⚠️ Email není nastaven: chybí EMAIL_SENDER/EMAIL_RECEIVER/GMAILPASSWORD.")
        return

    subject = f"[Radar] {tag} {now.strftime('%Y-%m-%d %H:%M')}"
    body = (report.get("rendered_text") or report.get("text") or "").strip()
    if not body:
        body = "(empty report)"

    msg = MIMEMultipart()
    msg["From"] = sender
    msg["To"] = receiver
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain", "utf-8"))

    # attachments (charts)
    for p in (attachments or []):
        try:
            if not p or not os.path.exists(p):
                continue
            part = MIMEBase("application", "octet-stream")
            with open(p, "rb") as f:
                part.set_payload(f.read())
            encoders.encode_base64(part)
            filename = os.path.basename(p)
            part.add_header("Content-Disposition", f'attachment; filename="{filename}"')
            msg.attach(part)
        except Exception:
            continue

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(sender, password)
            server.sendmail(sender, [receiver], msg.as_string())
            print(f"✅ Email odeslán: {receiver} ({tag})")
    except Exception as e:
        print("Email error:", e)
