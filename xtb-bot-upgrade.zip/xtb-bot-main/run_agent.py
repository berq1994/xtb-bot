# run_agent.py
from __future__ import annotations

import sys
from datetime import datetime

from radar.config import load_config
from radar.state import State
from radar.agent import RadarAgent

try:
    from reporting.telegram import telegram_poll_and_dispatch, telegram_send_menu
except Exception:  # pragma: no cover
    telegram_poll_and_dispatch = None  # type: ignore
    telegram_send_menu = None  # type: ignore


def main(argv: list[str]) -> int:
    mode = (argv[1] if len(argv) > 1 else "snapshot").strip().lower()
    cfg = load_config()
    st = State(cfg.state_dir)
    agent = RadarAgent(cfg=cfg, st=st)

    now = datetime.now()

    if mode == "snapshot":
        resp = agent.snapshot(now=now, reason="scheduled")
        print(resp.markdown)
        return 0

    if mode == "alerts":
        resp = agent.alerts(now=now)
        print(resp.markdown)
        return 0

    if mode == "earnings":
        resp = agent.earnings(now=now)
        print(resp.markdown)
        return 0

    if mode in ("geo", "geopolitics"):
        resp = agent.geopolitics(now=now)
        print(resp.markdown)
        return 0

    if mode in ("menu",):
        if telegram_send_menu is not None:
            telegram_send_menu(cfg)
        return 0

    if mode in ("poll", "telegram"):
        if telegram_poll_and_dispatch is None:
            print("telegram_poll_and_dispatch není dostupný")
            return 1
        out = telegram_poll_and_dispatch(cfg, agent, st=st)
        print(out)
        return 0

    # fallback
    resp = agent.handle("help", now=now)
    print(resp.markdown)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
