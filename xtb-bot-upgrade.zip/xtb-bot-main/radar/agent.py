# radar/agent.py
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from radar.config import RadarConfig
from radar.engine import (
    run_radar_snapshot,
    run_alerts_snapshot,
    run_weekly_earnings_table,
    map_ticker,
    news_combined,
    why_from_headlines,
    last_close_prev_close,
    volume_ratio_1d,
    market_regime,
    geopolitics_digest,
    learn_geopolitics_keywords,
)
from radar.state import State

try:
    from reporting.telegram import (
        telegram_send_long,
        telegram_send_menu,
        telegram_send_photo,
    )
except Exception:  # pragma: no cover
    from telegram import telegram_send_long, telegram_send_menu, telegram_send_photo  # type: ignore

try:
    from reporting.emailer import maybe_send_email_report
except Exception:  # pragma: no cover
    from emailer import maybe_send_email_report  # type: ignore

try:
    from reporting.charts import make_price_chart
except Exception:  # pragma: no cover
    make_price_chart = None  # type: ignore


@dataclass
class AgentResponse:
    title: str
    markdown: str
    payload: Optional[Dict[str, Any]] = None


class RadarAgent:
    """Agent nad radarem.

    Co řeší:
    - příkazy (snapshot/alerts/earnings/geo/explain/…)
    - reporting do Telegramu + volitelně email
    - základní UX přes Telegram menu
    - jednoduchý learning loop pro geopolitiku (váhy keywordů) v .state/geo.json
    """

    def __init__(self, cfg: RadarConfig, st: Optional[State] = None):
        self.cfg = cfg
        self.st = st or State(cfg.state_dir)

    # ----------------- public entry -----------------
    def handle(self, text: str, now: Optional[datetime] = None) -> AgentResponse:
        now = now or datetime.now()
        cmd, args = self._parse(text)

        if cmd in ("help", "?"):
            return self._help()

        if cmd == "menu":
            try:
                telegram_send_menu(self.cfg)
            except Exception:
                pass
            return AgentResponse("Menu", "Odeslal jsem ovládací menu do Telegramu (pokud je nastavený token/chat_id).")

        if cmd == "snapshot":
            return self.snapshot(now=now, reason="manual")

        if cmd == "alerts":
            return self.alerts(now=now)

        if cmd == "earnings":
            return self.earnings(now=now)

        if cmd in ("geo", "geopolitics"):
            return self.geopolitics(now=now)

        if cmd == "explain":
            if not args:
                return AgentResponse("Explain", "Použití: `explain TICKER`")
            return self.explain(ticker=args[0], now=now)

        # fallback: když user napíše jen ticker
        if cmd and cmd.isalpha() and 1 <= len(cmd) <= 10 and not args:
            return self.explain(ticker=cmd, now=now)

        return AgentResponse("Neznámý příkaz", f"Neznámý příkaz: `{text}`\n\nNapiš `help`.")

    # ----------------- core actions -----------------
    def snapshot(self, now: datetime, reason: str = "snapshot") -> AgentResponse:
        snap = run_radar_snapshot(cfg=self.cfg, now=now, reason=reason, universe=None, st=self.st)
        md = self._format_snapshot(snap)

        # volitelně grafy top 3 tickery
        charts: List[str] = []
        if make_price_chart is not None:
            try:
                top = (snap.get("top") or [])[:3]
                for r in top:
                    t = str(r.get("ticker") or "").strip().upper()
                    if t:
                        p = make_price_chart(ticker=map_ticker(self.cfg, t), days=30, out_dir=self.cfg.state_dir)
                        if p:
                            charts.append(p)
            except Exception:
                charts = []

        self._report(tag=reason or "snapshot", title="Radar snapshot", text=md, attachments=charts)
        self._audit("snapshot", {"reason": reason, "meta": snap.get("meta", {}), "top": snap.get("top", [])})
        self.st.save()
        return AgentResponse("Radar snapshot", md, payload=snap)

    def alerts(self, now: datetime) -> AgentResponse:
        alerts = run_alerts_snapshot(cfg=self.cfg, now=now, st=self.st)
        md = self._format_alerts(alerts, now=now)
        self._report(tag="alerts", title="Alerty", text=md)
        self._audit("alerts", {"count": len(alerts), "alerts": alerts})
        self.st.save()
        return AgentResponse("Alerty", md, payload={"alerts": alerts})

    def earnings(self, now: datetime) -> AgentResponse:
        table = run_weekly_earnings_table(cfg=self.cfg, now=now, st=self.st)
        md = self._format_earnings(table)
        self._report(tag="earnings", title="Earnings týden", text=md)
        self._audit("earnings", {"meta": table.get("meta", {}), "count": len(table.get("rows", []))})
        self.st.save()
        return AgentResponse("Earnings týden", md, payload=table)

    def geopolitics(self, now: datetime) -> AgentResponse:
        learn_meta: Dict[str, Any] = {}
        try:
            learn_meta = learn_geopolitics_keywords(cfg=self.cfg, now=now, st=self.st) or {}
        except Exception as e:
            learn_meta = {"ok": False, "reason": f"learn_fail: {e}"}

        dg = geopolitics_digest(cfg=self.cfg, now=now, st=self.st)
        md = self._format_geopolitics(dg, learn_meta=learn_meta)
        self._report(tag="geo", title="Geopolitika", text=md)
        self._audit("geopolitics", {"day": dg.get("meta", {}).get("day"), "items": len(dg.get("items", []) or []), "learn": learn_meta})
        self.st.save()
        return AgentResponse("Geopolitika", md, payload={"digest": dg, "learn": learn_meta})

    def explain(self, ticker: str, now: datetime) -> AgentResponse:
        raw = ticker.strip().upper()
        resolved = map_ticker(self.cfg, raw)
        regime_label, regime_detail, _ = market_regime(self.cfg)

        lc = last_close_prev_close(resolved)
        pct_1d = None
        last = prev = None
        if lc:
            last, prev = lc
            if prev:
                pct_1d = ((last - prev) / prev) * 100.0

        vol_ratio = volume_ratio_1d(resolved)
        news = news_combined(resolved, int(self.cfg.news_per_ticker or 2))
        why = why_from_headlines(news)

        md: List[str] = []
        md.append(f"## {raw} ({resolved})")
        md.append(f"- **Tržní režim:** **{regime_label}** — {regime_detail}")
        if last is not None and prev is not None:
            md.append(f"- **Close:** {last:.4g} (předtím {prev:.4g})")
        if pct_1d is None:
            md.append("- **Změna 1D:** nedostupné")
        else:
            md.append(f"- **Změna 1D:** **{pct_1d:+.2f}%**")
        md.append(f"- **Objem vs průměr (20D):** **{vol_ratio:.2f}×**")

        md.append("\n### Co to znamená (signál, ne doporučení)")
        md.append(self._actionable_interpretation(pct_1d=pct_1d, vol_ratio=vol_ratio, has_news=bool(news), regime=regime_label))

        md.append("\n### Proč se to hýbe (z headline)")
        md.append(f"- {why}")

        if news:
            md.append("\n### Top zprávy")
            for src, title, url in news[: min(6, len(news))]:
                md.append(f"- **{src}**: [{title}]({url})")
        else:
            md.append("\n### Zprávy")
            md.append("- Nic jasného v RSS – často je to sentiment/technika/trh.")

        out = "\n".join(md)

        # graf pro explain (pokud je chart modul)
        attachments: List[str] = []
        if make_price_chart is not None:
            try:
                p = make_price_chart(ticker=resolved, days=60, out_dir=self.cfg.state_dir)
                if p:
                    attachments.append(p)
            except Exception:
                pass

        self._report(tag=f"explain_{raw}", title=f"Explain {raw}", text=out, attachments=attachments)
        self._audit("explain", {"ticker": raw, "resolved": resolved, "pct_1d": pct_1d, "vol_ratio": vol_ratio, "news_n": len(news)})
        self.st.save()
        return AgentResponse(f"Explain {raw}", out)

    # ----------------- helpers -----------------
    def _parse(self, text: str) -> Tuple[str, List[str]]:
        t = (text or "").strip()
        if not t:
            return "help", []
        parts = t.split()
        cmd = parts[0].lower()
        args = parts[1:]
        if cmd.startswith("/"):
            cmd = cmd[1:]
        return cmd, args

    def _help(self) -> AgentResponse:
        md = """## Radar Agent — příkazy

- `menu` … pošle ovládací menu do Telegramu
- `snapshot` … kompletní radar top/worst (+ grafy TOP 3)
- `alerts` … intradenní alerty (od open)
- `earnings` … earnings tabulka na týden
- `geo` … geopolitické zprávy (top headlines + dopad + learning)
- `explain TICKER` … co se děje + proč + co hlídat (+ graf)

Pozn.: výstupy jsou *signály a kontext*, ne investiční doporučení.
"""
        return AgentResponse("Help", md)

    def _format_snapshot(self, snap: Dict[str, Any]) -> str:
        meta = snap.get("meta", {})
        regime = (meta.get("market_regime") or {})
        lines: List[str] = []
        lines.append(f"## Radar snapshot ({meta.get('timestamp','')})")
        lines.append(f"- Režim: **{regime.get('label','?')}** — {regime.get('detail','')}")
        lines.append("")
        lines.append("⚠️ *Tohle není investiční doporučení. Ber to jako radar signálů + kontext.*")
        lines.append("")

        top = snap.get("top", []) or []
        worst = snap.get("worst", []) or []

        lines.append("### TOP (kandidáti k dalšímu sledování / momentum)")
        if not top:
            lines.append("- (prázdné)")
        for r in top:
            lines.append(self._fmt_row(r))

        lines.append("\n### WORST (riziko / slabost / možný mean-reversion)")
        if not worst:
            lines.append("- (prázdné)")
        for r in worst:
            lines.append(self._fmt_row(r))

        # „denní playbook“ – obecný, ne buy/sell
        lines.append("\n### Denní playbook (obecně)")
        lines.append(self._daily_playbook(meta))

        return "\n".join(lines)

    def _daily_playbook(self, meta: Dict[str, Any]) -> str:
        regime = (meta.get("market_regime") or {}).get("label", "—")
        if regime == "RISK-OFF":
            return """- Preferuj menší pozice / vyšší cash / kratší horizont.
- Sleduj **VIX**, **USD**, **ropa**, korelace (když vše padá spolu).
- U longů čekej na potvrzení (2 dny follow-through), u slabých titulů hlídej supporty."""
        if regime == "RISK-ON":
            return """- Momentum má vyšší šanci pokračovat – ale hlídej falešné breaky na nízkém objemu.
- U top signálů: čekej na pullback nebo breakout s objemem.
- U slabých: mean-reversion je častější, když trh jede risk-on."""
        return """- Mix režim: drž se pravidel risku, ne headline.
- Pokud je hodně zpráv a nízký objem → pozor na šum."""

    def _fmt_row(self, r: Dict[str, Any]) -> str:
        t = r.get("ticker", "?")
        c = r.get("company", "—")
        pct_1d = r.get("pct_1d", None)
        sc = r.get("score", 0.0)
        why = r.get("why", "")
        pct_txt = "n/a" if pct_1d is None else f"{pct_1d:+.2f}%"
        lvl = r.get("level", "")
        return f"- **{t}** ({c}) — **{pct_txt}**, score **{sc:.1f}**, level **{lvl}**\n  - proč: {why}"

    def _format_alerts(self, alerts: List[Dict[str, Any]], now: datetime) -> str:
        lines = [f"## Alerty ({now.strftime('%Y-%m-%d %H:%M')})", ""]
        if not alerts:
            lines.append("- Nic nepřekročilo práh.")
            return "\n".join(lines)

        lines.append(f"Prahová změna od open: **±{float(self.cfg.alert_threshold_pct):.1f}%**\n")
        for a in alerts:
            t = a.get("ticker", "?")
            c = a.get("company", "—")
            ch = float(a.get("pct_from_open", 0.0))
            lines.append(f"- **{t}** ({c}) — **{ch:+.2f}%** (open {a.get('open')}, last {a.get('last')})")
        return "\n".join(lines)

    def _format_earnings(self, table: Dict[str, Any]) -> str:
        meta = table.get("meta", {})
        rows = table.get("rows", []) or []
        lines = [f"## Earnings ({meta.get('from','')} → {meta.get('to','')})", ""]
        if not rows:
            lines.append("- Nic z univerza v kalendáři.")
            return "\n".join(lines)

        lines.append("| Datum | Čas | Symbol | Firma | EPS est | Rev est |")
        lines.append("|---|---|---|---|---:|---:|")
        for r in rows:
            lines.append(
                f"| {r.get('date','')} | {r.get('time','')} | **{r.get('symbol','')}** | {r.get('company','—')} | {r.get('eps_est','')} | {r.get('rev_est','')} |"
            )
        return "\n".join(lines)

    def _actionable_interpretation(self, pct_1d: Optional[float], vol_ratio: float, has_news: bool, regime: str) -> str:
        notes: List[str] = []

        if pct_1d is None:
            notes.append("- Nemám spolehlivá 1D data → ber to jako informativní.")
        else:
            if abs(pct_1d) >= 6:
                notes.append("- **Velký pohyb**: typicky news/earnings/sector move → ověř headline a kontext (pre/after-market).")
            elif abs(pct_1d) >= 3:
                notes.append("- **Výrazný pohyb**: často katalyzátor + momentum → sleduj další den (follow-through vs mean-reversion).")
            else:
                notes.append("- **Běžný pohyb**: signál může být spíš o trendu/market režimu než o jedné zprávě.")

        if vol_ratio >= 1.8:
            notes.append("- **Objem je nadprůměrný** → pohyb má větší „váhu“ (méně náhodný).")
        elif vol_ratio <= 0.7:
            notes.append("- **Objem je slabý** → pohyb může být „thin“ (méně důvěryhodný).")

        if has_news:
            notes.append("- **Jsou zprávy** → validuj hlavně *earnings/guidance/downgrade/regulace/kontrakty*.")
        else:
            notes.append("- **Bez jasných zpráv** → často trh/ETF flow/technika (support/resistance).")

        if regime == "RISK-OFF":
            notes.append("- **RISK-OFF režim** → více šumu a výplachů, drž menší risk a hlídej korelace.")
        elif regime == "RISK-ON":
            notes.append("- **RISK-ON režim** → momentum má vyšší šanci pokračovat, ale pozor na falešné breaky.")

        return "\n".join(notes)

    def _format_geopolitics(self, dg: Dict[str, Any], learn_meta: Optional[Dict[str, Any]] = None) -> str:
        meta = dg.get("meta", {}) if isinstance(dg, dict) else {}
        items = dg.get("items", []) if isinstance(dg, dict) else []
        lines: List[str] = []
        lines.append(f"## Geopolitika ({meta.get('day','')})")
        if meta.get("cached"):
            lines.append("- (cache pro dnešní den)")
        if learn_meta:
            if learn_meta.get("ok"):
                lines.append(f"- Learn: ✅ market_signal={learn_meta.get('market_signal'):.2f}, boost={learn_meta.get('boost'):.3f}")
            else:
                rsn = learn_meta.get("reason")
                if rsn:
                    lines.append(f"- Learn: — {rsn}")

        lines.append("")
        if not items:
            lines.append("- Nic výrazného v geo RSS (nebo bez keyword hitů).")
            return "\n".join(lines)

        lines.append("### TOP zprávy (co může pohnout trhem)")
        for it in items[:10]:
            src = it.get("src", "")
            title = it.get("title", "")
            url = it.get("url", "")
            sc = it.get("score", 0.0)
            kws = it.get("keywords", [])
            kw_txt = ", ".join(kws[:6])
            lines.append(f"- **{sc:.2f}** **{src}**: [{title}]({url})")
            if kw_txt:
                lines.append(f"  - klíče: `{kw_txt}`")

        # rychlá interpretace
        lines.append("\n### Prakticky (jak to číst)")
        lines.append("""- Geo šok typicky = **risk-off**: akcie dolů, **ropa** a **zlato** nahoru, posílení **USD**.
- Nejvíc trpí: aerolinky, shipping/logistika, cyklické sektory.
- Nejvíc profitují: energie (ropa/plyn), obrana, některé komodity.
- Klíčový trigger: **Strait of Hormuz** (průchod ropy) a rétorika o odvetě.""")
        return "\n".join(lines)

    def _report(self, tag: str, title: str, text: str, attachments: Optional[List[str]] = None) -> None:
        """Report do Telegramu + volitelně email.

        - Telegram: vždy pokud je nastavený token/chat_id.
        - Email: jen pokud EMAIL_ENABLED=true.
        """
        attachments = attachments or []

        # Telegram text
        try:
            telegram_send_long(self.cfg, text)
        except Exception:
            pass

        # Telegram attachments (charts)
        for p in attachments:
            try:
                telegram_send_photo(self.cfg, p, caption=None)
            except Exception:
                pass

        # Email
        try:
            maybe_send_email_report(self.cfg, {"rendered_text": text}, datetime.now(), tag=tag, attachments=attachments)
        except Exception:
            pass

    def _audit(self, event: str, data: Dict[str, Any]) -> None:
        import os
        import json

        os.makedirs(self.cfg.state_dir, exist_ok=True)
        path = os.path.join(self.cfg.state_dir, "agent_log.jsonl")
        record = {
            "ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "event": event,
            "data": data,
        }
        try:
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        except Exception:
            pass
